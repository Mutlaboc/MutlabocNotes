Исправление для ветки feature/android-notes-backend-migration

Что меняется:
1. Email/password вход и регистрация переводятся на backend endpoints:
   - POST /auth/login
   - POST /auth/register
2. После успешного ответа backend access/refresh token сохраняются в SessionManager.
3. Notes/HomeCards начинают работать и после входа по email/password, а не только после Google.

Какие файлы заменить:
- MutlabocNotes/app/src/main/java/com/example/mutlabocsnotes/auth/AuthDtos.kt
- MutlabocNotes/app/src/main/java/com/example/mutlabocsnotes/auth/AuthApi.kt
- MutlabocNotes/app/src/main/java/com/example/mutlabocsnotes/auth/BackendAuthRepository.kt
- MutlabocNotes/app/src/main/java/com/example/mutlabocsnotes/AuthScreen.kt

После замены:
1. Sync Gradle
2. Rebuild Project
3. Проверь:
   - Sign In по существующему backend-аккаунту
   - Sign Up для нового backend-аккаунта
   - загрузку заметок и карточек после входа

Примечание:
Если пользователь был раньше только в Firebase email/password, а в backend ещё не создан,
то backend Sign In может вернуть invalid_email_or_password. Тогда нужен backend Sign Up
или отдельная миграция аккаунтов.
